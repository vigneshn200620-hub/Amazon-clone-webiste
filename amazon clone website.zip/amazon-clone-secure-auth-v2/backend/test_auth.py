import re
import time
import unittest
import uuid
import app as m

class Browser:
    """Acts like the web page: keeps the cookie and the CSRF token, and swaps in the new
    token whenever the server sends one (this is what script.js does)."""

    def __init__(self, ip="10.0.0.1"):
        self.c = m.app.test_client()
        self.ip = ip
        html = self.c.get("/", environ_base={"REMOTE_ADDR": ip}).get_data(as_text=True)
        self.token = re.search(r'name="csrf-token" content="([^"]+)"', html).group(1)

    def _take_token(self, response):
        data = response.get_json(silent=True) or {}
        if "csrf" in data:
            self.token = data["csrf"]
        return response

    def post(self, url, body=None, token="auto"):
        headers = {"X-CSRFToken": self.token} if token == "auto" else ({"X-CSRFToken": token} if token else {})
        return self._take_token(self.c.post(url, json=body or {}, headers=headers, environ_base={"REMOTE_ADDR": self.ip}))

    def get(self, url):
        return self._take_token(self.c.get(url, environ_base={"REMOTE_ADDR": self.ip}))

def new_email():
    return f"test-{uuid.uuid4().hex[:10]}@example.com"

STRONG = "Tr0ub4dor&3-horse"

def register(browser, email=None, password=STRONG, name="Test User"):
    email = email or new_email()
    r = browser.post("/api/register", {"name": name, "email": email, "password": password})
    assert r.status_code == 201, r.get_json()
    return email


class AuthTests(unittest.TestCase):
    def setUp(self):
        m.limiter.reset()

    @classmethod
    def tearDownClass(cls):
        m.execute("DELETE o FROM orders o JOIN users u ON u.id = o.user_id WHERE u.email LIKE 'test-%@example.com'")
        m.execute("DELETE FROM users WHERE email LIKE 'test-%@example.com'")      # sessions and reset links go with them

    # CSRF + sessions
    def test_request_without_csrf_token_is_blocked(self):
        b = Browser()
        self.assertEqual(b.post("/api/login", {"email": "a@b.co", "password": "x"}, token=None).status_code, 400)

    def test_csrf_token_is_refreshed_after_login_and_logout(self):
        b = Browser(); old = b.token
        register(b)
        self.assertNotEqual(b.token, old)                                   # the server sent a new one
        self.assertEqual(b.post("/api/orders", {"items": [{"id": 1, "qty": 1}]}).status_code, 201)   # works now
        self.assertEqual(b.post("/api/orders", {"items": [{"id": 1, "qty": 1}]}, token=old).status_code, 400)  # stale token fails
        self.assertEqual(b.post("/api/logout").status_code, 200)            # logout works with the refreshed token

    def test_login_cookie_has_a_real_lifetime(self):
        b = Browser(); email = register(b); b.post("/api/logout")
        r = b.post("/api/login", {"email": email, "password": STRONG})
        cookie = r.headers.get("Set-Cookie", "")
        self.assertIn("HttpOnly", cookie); self.assertIn("SameSite=Lax", cookie)
        self.assertTrue("Expires=" in cookie or "Max-Age=" in cookie, cookie)

    def test_logout_really_ends_the_session_even_for_a_copied_cookie(self):
        b = Browser(); register(b)
        stolen = b.c.get_cookie("session").value
        b.post("/api/logout")
        thief = m.app.test_client(); thief.set_cookie("session", stolen)
        self.assertIsNone(thief.get("/api/me").get_json()["user"])

    def test_sign_out_of_all_devices(self):
        b1 = Browser("10.0.0.1"); email = register(b1)
        b2 = Browser("10.0.0.2"); self.assertEqual(b2.post("/api/login", {"email": email, "password": STRONG}).status_code, 200)
        self.assertEqual(b1.post("/api/logout-all").status_code, 200)
        self.assertIsNone(b2.get("/api/me").get_json()["user"])

    def test_expired_session_is_rejected(self):
        b = Browser(); register(b)
        m.execute("UPDATE auth_sessions SET expires_at = NOW() - INTERVAL 1 MINUTE WHERE user_id IN (SELECT id FROM users WHERE email LIKE 'test-%@example.com')")
        self.assertIsNone(b.get("/api/me").get_json()["user"])
        self.assertEqual(b.post("/api/orders", {"items": [{"id": 1, "qty": 1}]}).status_code, 401)

    def test_protected_routes_need_login(self):
        b = Browser()
        self.assertEqual(b.get("/api/orders").status_code, 401)
        self.assertEqual(b.post("/api/orders", {"items": [{"id": 1, "qty": 1}]}).status_code, 401)

    #passwords
    def test_password_rules(self):
        for bad in ("short1", "12345678", "password", "password123", "aaaaaaaaaaaa", "a" * 129):
            m.limiter.reset()
            r = Browser().post("/api/register", {"name": "Tester", "email": new_email(), "password": bad})
            self.assertEqual(r.status_code, 400, bad[:12])
        m.limiter.reset()
        email = new_email()
        r = Browser().post("/api/register", {"name": "Tester", "email": email, "password": email})   # password == email
        self.assertEqual(r.status_code, 400)
        self.assertEqual(Browser().post("/api/register", {"name": "Tester", "email": new_email(), "password": STRONG}).status_code, 201)

    #brute force
    def test_correct_logins_are_never_blocked(self):
        email = register(Browser("10.0.1.1")); results = []
        for _ in range(8):
            results.append(Browser("10.0.1.2").post("/api/login", {"email": email, "password": STRONG}).status_code)
        self.assertEqual(set(results), {200})

    def test_account_is_locked_after_five_wrong_passwords_from_anywhere(self):
        email = register(Browser("10.0.2.1")); other = register(Browser("10.0.2.2"))
        for i in range(5):                                              # five different computers
            self.assertEqual(Browser(f"10.0.3.{i}").post("/api/login", {"email": email, "password": "wrong-pw-%d" % i}).status_code, 401)
        r = Browser("10.0.3.99").post("/api/login", {"email": email, "password": STRONG})   # even the right password
        self.assertEqual(r.status_code, 429)
        self.assertEqual(Browser("10.0.3.98").post("/api/login", {"email": other, "password": STRONG}).status_code, 200)   # others fine

    def test_unknown_email_and_wrong_password_look_the_same(self):
        email = register(Browser("10.0.4.1")); b = Browser("10.0.4.2")
        def timed(addr):
            t = time.time(); r = b.post("/api/login", {"email": addr, "password": "wrong-password-1"}); m.limiter.reset()
            return r.get_json(), time.time() - t
        known, t_known = timed(email); unknown, t_unknown = timed("nobody-%s@example.com" % uuid.uuid4().hex[:6])
        self.assertEqual(known, unknown)
        self.assertLess(max(t_known, t_unknown) / min(t_known, t_unknown), 3, (t_known, t_unknown))

    #change password
    def test_change_password(self):
        b1 = Browser("10.0.5.1"); email = register(b1)
        b2 = Browser("10.0.5.2"); b2.post("/api/login", {"email": email, "password": STRONG})
        post = lambda cur, new: b1.post("/api/change-password", {"current_password": cur, "new_password": new})
        self.assertEqual(post("wrong-current-pw", "Another-Str0ng-pw").status_code, 400)
        self.assertEqual(post(STRONG, "password123").status_code, 400)
        self.assertEqual(post(STRONG, STRONG).status_code, 400)
        self.assertEqual(post(STRONG, "Another-Str0ng-pw").status_code, 200)
        self.assertEqual(b1.get("/api/me").get_json()["user"]["email"], email)        # this device stays signed in
        self.assertIsNone(b2.get("/api/me").get_json()["user"])                       # the other device is signed out
        self.assertEqual(Browser("10.0.5.3").post("/api/login", {"email": email, "password": STRONG}).status_code, 401)
        self.assertEqual(Browser("10.0.5.4").post("/api/login", {"email": email, "password": "Another-Str0ng-pw"}).status_code, 200)

    def test_change_password_needs_login(self):
        self.assertEqual(Browser().post("/api/change-password", {"current_password": "x", "new_password": STRONG}).status_code, 401)

    #forgot / reset password
    def capture_mail(self):
        self.mails = []
        original = m.send_mail
        m.send_mail = lambda to, subject, body: self.mails.append((to, body))
        self.addCleanup(setattr, m, "send_mail", original)

    def wait_for_mail(self, count):
        for _ in range(40):
            if len(self.mails) >= count:
                return
            time.sleep(0.05)
        self.fail("no email was sent")

    def test_forgot_and_reset_password(self):
        self.capture_mail()
        victim = Browser("10.0.6.1"); email = register(victim)
        # unknown email: same answer, no email
        r = Browser("10.0.6.2").post("/api/forgot-password", {"email": new_email()})
        self.assertEqual((r.status_code, r.get_json()), (200, {"ok": True}))
        time.sleep(0.2); self.assertEqual(self.mails, [])
        # known email: same answer + an email with a one-time link
        r = Browser("10.0.6.3").post("/api/forgot-password", {"email": email})
        self.assertEqual((r.status_code, r.get_json()), (200, {"ok": True}))
        self.wait_for_mail(1)
        token = re.search(r"#reset=([\w-]+)", self.mails[0][1]).group(1)
        # the database stores only a hash of the token
        self.assertIsNone(m.fetch_one("SELECT id FROM password_resets WHERE token_hash = %s", (token,)))
        b = Browser("10.0.6.4")
        self.assertEqual(b.post("/api/reset-password", {"token": token, "password": "password123"}).status_code, 400)   # weak
        self.assertEqual(b.post("/api/reset-password", {"token": "not-a-real-token", "password": STRONG}).status_code, 400)
        self.assertEqual(b.post("/api/reset-password", {"token": token, "password": "Brand-New-Passw0rd"}).status_code, 200)
        self.assertEqual(b.post("/api/reset-password", {"token": token, "password": "Brand-New-Passw0rd2"}).status_code, 400)   # one use only
        self.assertIsNone(victim.get("/api/me").get_json()["user"])                                                # signed out everywhere
        self.assertEqual(Browser("10.0.6.5").post("/api/login", {"email": email, "password": STRONG}).status_code, 401)
        self.assertEqual(Browser("10.0.6.6").post("/api/login", {"email": email, "password": "Brand-New-Passw0rd"}).status_code, 200)

    def test_reset_link_expires_and_new_request_cancels_old_link(self):
        self.capture_mail()
        email = register(Browser("10.0.7.1"))
        Browser("10.0.7.2").post("/api/forgot-password", {"email": email}); self.wait_for_mail(1)
        Browser("10.0.7.3").post("/api/forgot-password", {"email": email}); self.wait_for_mail(2)
        first, second = [re.search(r"#reset=([\w-]+)", body).group(1) for _, body in self.mails]
        b = Browser("10.0.7.4")
        self.assertEqual(b.post("/api/reset-password", {"token": first, "password": STRONG + "1"}).status_code, 400)     # replaced
        m.execute("UPDATE password_resets SET expires_at = NOW() - INTERVAL 1 MINUTE WHERE user_id IN (SELECT id FROM users WHERE email LIKE 'test-%@example.com')")
        self.assertEqual(b.post("/api/reset-password", {"token": second, "password": STRONG + "1"}).status_code, 400)    # expired

    def test_forgot_password_is_rate_limited(self):
        self.capture_mail(); email = register(Browser("10.0.8.1")); codes = []
        for i in range(4):
            codes.append(Browser(f"10.0.8.{10 + i}").post("/api/forgot-password", {"email": email}).status_code)
        self.assertEqual(codes, [200, 200, 200, 429])

if __name__ == "__main__":
    unittest.main()
