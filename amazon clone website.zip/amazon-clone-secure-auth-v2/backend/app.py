import hashlib
import os
import secrets
import smtplib
import ssl
import threading
from email.message import EmailMessage
from functools import wraps

import mysql.connector
from dotenv import load_dotenv
from flask import Flask, g, jsonify, render_template, request, session
from flask_wtf.csrf import CSRFProtect, CSRFError, generate_csrf
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))   # reads backend/.env

# The frontend lives in its own folder next to "backend"
app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "..", "frontend", "templates"),
    static_folder=os.path.join(BASE_DIR, "..", "frontend", "static"),
)

secret_key = os.getenv("SECRET_KEY", "").strip()
if len(secret_key) < 32:
    raise RuntimeError(
        "SECRET_KEY is missing or too short. Copy .env.example to .env and "
        "set SECRET_KEY to a random value of at least 32 characters."
    )
SESSION_SECONDS = 60 * 60 * 8          # a login lasts 8 hours
app.secret_key = secret_key
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("SESSION_COOKIE_SECURE", "false").lower() == "true",
    PERMANENT_SESSION_LIFETIME=SESSION_SECONDS,
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)

# CSRF protects cookie-authenticated POST requests.

csrf = CSRFProtect(app)

# In-memory limiter is suitable for a single local development process.
limiter = Limiter(key_func=get_remote_address, app=app, default_limits=[])

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "amazon_clone"),
}

# Settings for "forgot password" emails
APP_BASE_URL = os.getenv("APP_BASE_URL", "http://127.0.0.1:5000").strip().rstrip("/")
SMTP_HOST = os.getenv("SMTP_HOST", "").strip()
SMTP_PORT = int(os.getenv("SMTP_PORT") or 587)
SMTP_USER = os.getenv("SMTP_USER", "").strip()
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
MAIL_FROM = os.getenv("MAIL_FROM", "").strip() or SMTP_USER or "no-reply@localhost"

# 1. DATABASE HELPERS

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

def fetch_all(sql, params=()):
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params)
        return cur.fetchall()
    finally:
        conn.close()

def fetch_one(sql, params=()):
    rows = fetch_all(sql, params)
    return rows[0] if rows else None

def execute(sql, params=()):
    """INSERT / UPDATE / DELETE. Returns the new row id."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

# 2. SMALL HELPERS

def error(message, status=400):
    return jsonify({"error": message}), status

def with_csrf(data, status=200):
    """Adds a fresh CSRF token to the answer.
    Signing in or out starts a new session, which invalidates the old token - the page
    stores the new one and uses it for its next request."""
    data["csrf"] = generate_csrf()
    return jsonify(data), status

@app.errorhandler(CSRFError)
def csrf_error(err):
    return error("Security check failed. Refresh the page and try again.", 400)

@app.errorhandler(429)
def rate_limit_error(err):
    return error("Too many attempts. Please wait a few minutes and try again.", 429)

@app.errorhandler(mysql.connector.Error)
def database_error(err):
    app.logger.error("Database error: %s", err)
    return error("Database error. Is MySQL running and is .env correct?", 500)

# 3. PASSWORD RULES

COMMON_PASSWORDS = {
    "password", "password1", "password12", "password123", "passw0rd", "p@ssw0rd", "12345678", "123456789",
    "1234567890", "11111111", "00000000", "qwerty", "qwerty12", "qwerty123", "qwertyuiop", "abc12345",
    "abcd1234", "iloveyou", "letmein1", "welcome1", "welcome123", "admin123", "administrator", "monkey123",
    "dragon123", "football1", "baseball1", "sunshine1", "princess1", "superman1", "whatever1", "trustno1",
    "master123", "login123", "changeme", "changeme1", "amazon123", "amazon@123", "flipkart123", "india123",
    "india@123", "123123123", "123qweasd", "1q2w3e4r", "zaq12wsx", "demo1234", "test1234", "user1234", "guest123",
}
PASSWORD_MIN, PASSWORD_MAX = 8, 15

def password_problem(password, email, name):
    """Returns a message if the password is not acceptable, otherwise None."""
    if not PASSWORD_MIN <= len(password) <= PASSWORD_MAX:
        return f"Password must be {PASSWORD_MIN} to {PASSWORD_MAX} characters."
    low = password.lower()
    weak = (
        low in COMMON_PASSWORDS
        or low in (email, email.split("@")[0], name.lower())
        or password.isdigit()
        or len(set(password)) == 1
    )
    return "That password is too easy to guess. Please choose a stronger one." if weak else None

def valid_email(email):
    return len(email) <= 150 and "@" in email and "." in email.split("@")[-1]

# Used when the email is unknown, so "no such email" and "wrong password" take the same time.
DUMMY_HASH = generate_password_hash("this-is-not-a-real-password")

# 4. SESSIONS

def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()

def start_session(user):
    execute("DELETE FROM auth_sessions WHERE expires_at < NOW()")          # tidy up old sessions
    token = secrets.token_urlsafe(32)
    execute(
        "INSERT INTO auth_sessions (token_hash, user_id, expires_at) "
        "VALUES (%s, %s, DATE_ADD(NOW(), INTERVAL %s SECOND))",
        (hash_token(token), user["id"], SESSION_SECONDS),
    )
    session.clear()                 # a brand-new cookie on every login
    session["sid"] = token
    session.permanent = True        # makes the 8-hour lifetime really apply

def end_session():
    sid = session.get("sid")
    if sid:
        execute("DELETE FROM auth_sessions WHERE token_hash = %s", (hash_token(sid),))
    session.clear()

def current_user():
    """The signed-in user for this request (id, name, email), or None."""
    if "user" not in g:
        g.user = None
        sid = session.get("sid")
        if sid:
            g.user = fetch_one(
                "SELECT u.id, u.name, u.email FROM auth_sessions s JOIN users u ON u.id = s.user_id "
                "WHERE s.token_hash = %s AND s.expires_at > NOW()",
                (hash_token(sid),),
            )
            if g.user is None:
                session.clear()
    return g.user

def public_user(user):
    return {"id": user["id"], "name": user["name"], "email": user["email"]}

def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            return error("Please sign in first.", 401)
        return view(*args, **kwargs)
    return wrapper

# Rate-limit "keys": who is being counted
def email_from_body():
    data = request.get_json(silent=True) or {}
    return "email:" + str(data.get("email", "")).strip().lower()[:150]

def user_or_ip():
    user = current_user()
    return f"user:{user['id']}" if user else f"ip:{get_remote_address()}"

def login_failed(response):
    return response.status_code == 401          # only failed attempts count towards the limit

# 5. EMAIL  (used for the "forgot password" link)

def send_mail(to, subject, body):
    """Sends an email through your SMTP account. Without SMTP settings (DEV MODE) the message is
    printed in the terminal instead, so you can test everything without an email account."""
    if not SMTP_HOST:
        print(f"\n  [DEV MODE - SMTP not set] Email to {to}\n  Subject: {subject}\n  {body}\n", flush=True)
        return
    try:
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = MAIL_FROM, to, subject
        msg.set_content(body)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as smtp:
            smtp.starttls(context=ssl.create_default_context())
            if SMTP_USER:
                smtp.login(SMTP_USER, SMTP_PASSWORD)
            smtp.send_message(msg)
    except Exception as err:                     # never show mail problems to the visitor
        app.logger.error("Could not send email: %s", err)

# 6. PAGE

@app.route("/")
def home():
    return render_template("index.html")


# 7. PRODUCTS API     GET /api/products?q=phone&category=Electronics&prime=1

PRODUCT_COLUMNS = """
    SELECT id, title, category, price, old_price AS oldPrice,
           rating, reviews, image AS kw, is_prime AS prime
    FROM products
"""

@app.route("/api/products")
def products():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()

    sql = PRODUCT_COLUMNS + " WHERE 1 = 1"
    params = []
    if q:
        sql += " AND title LIKE %s"
        params.append(f"%{q}%")
    if category and category.lower() != "all":
        sql += " AND category = %s"
        params.append(category)
    if request.args.get("prime") == "1":
        sql += " AND is_prime = 1"
    sql += " ORDER BY id"

    rows = fetch_all(sql, params)
    for row in rows:
        row["prime"] = bool(row["prime"])
    return jsonify(rows)



# 8. ACCOUNT API
#    register, login, logout, who am I, forgot / reset / change password, sign out everywhere
@app.route("/api/register", methods=["POST"])
@limiter.limit("10 per hour")
@limiter.limit("5 per minute")
def register():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))

    if not 2 <= len(name) <= 100:
        return error("Please enter your name.")
    if not valid_email(email):
        return error("Please enter a valid email address.")
    problem = password_problem(password, email, name)
    if problem:
        return error(problem)
    if fetch_one("SELECT id FROM users WHERE email = %s", (email,)):
        return error("An account with this email already exists.", 409)

    try:
        user_id = execute(
            "INSERT INTO users (name, email, password_hash) VALUES (%s, %s, %s)",
            (name, email, generate_password_hash(password)),
        )
    except mysql.connector.IntegrityError:        # two people registered the same email at once
        return error("An account with this email already exists.", 409)
    user = {"id": user_id, "name": name, "email": email}
    start_session(user)
    return with_csrf({"user": public_user(user)}, 201)


@app.route("/api/login", methods=["POST"])
@limiter.limit("20 per 10 minutes", deduct_when=login_failed)                         # per computer
@limiter.limit("5 per 15 minutes", key_func=email_from_body, deduct_when=login_failed)  # per account
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))

    user = fetch_one("SELECT id, name, email, password_hash FROM users WHERE email = %s", (email,))
    stored = user["password_hash"] if user else DUMMY_HASH
    password_ok = len(password) <= PASSWORD_MAX and check_password_hash(stored, password)
    # Same message and same work for "no such email" and "wrong password" on purpose.
    if not (user and password_ok):
        return error("Incorrect email or password.", 401)

    start_session(user)
    return with_csrf({"user": public_user(user)})

@app.route("/api/logout", methods=["POST"])
def logout():
    end_session()
    return with_csrf({"ok": True})

@app.route("/api/logout-all", methods=["POST"])
@login_required
def logout_all():
    """Signs this account out on every device."""
    execute("DELETE FROM auth_sessions WHERE user_id = %s", (current_user()["id"],))
    session.clear()
    return with_csrf({"ok": True})

@app.route("/api/me")
def me():
    user = current_user()
    return with_csrf({"user": user and public_user(user)})

@app.route("/api/change-password", methods=["POST"])
@login_required
@limiter.limit("5 per 15 minutes", key_func=user_or_ip, deduct_when=lambda r: r.status_code == 400)
def change_password():
    user = current_user()
    data = request.get_json(silent=True) or {}
    current = str(data.get("current_password", ""))
    new = str(data.get("new_password", ""))

    row = fetch_one("SELECT password_hash FROM users WHERE id = %s", (user["id"],))
    if len(current) > PASSWORD_MAX or not check_password_hash(row["password_hash"], current):
        return error("Your current password is incorrect.")
    problem = password_problem(new, user["email"], user["name"])
    if problem:
        return error(problem)
    if new == current:
        return error("Choose a password different from your current one.")

    execute("UPDATE users SET password_hash = %s WHERE id = %s", (generate_password_hash(new), user["id"]))
    # every OTHER device is signed out; this one stays signed in
    execute("DELETE FROM auth_sessions WHERE user_id = %s AND token_hash <> %s",
            (user["id"], hash_token(session["sid"])))
    return jsonify({"ok": True})

@app.route("/api/forgot-password", methods=["POST"])
@limiter.limit("5 per hour")
@limiter.limit("3 per hour", key_func=email_from_body)
def forgot_password():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()

    user = fetch_one("SELECT id, name FROM users WHERE email = %s", (email,)) if valid_email(email) else None
    if user:
        execute("UPDATE password_resets SET used_at = NOW() WHERE user_id = %s AND used_at IS NULL", (user["id"],))
        token = secrets.token_urlsafe(32)             # the link holds the token; MySQL keeps only its hash
        execute(
            "INSERT INTO password_resets (user_id, token_hash, expires_at) "
            "VALUES (%s, %s, DATE_ADD(NOW(), INTERVAL 30 MINUTE))",
            (user["id"], hash_token(token)),
        )
        link = f"{APP_BASE_URL}/#reset={token}"
        body = (f"Hello {user['name']},\n\nUse this link to choose a new password (valid for 30 minutes):\n{link}\n\n"
                "If you did not ask for this, you can ignore this email - your password stays the same.")
        threading.Thread(target=send_mail, args=(email, "Reset your password", body), daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/reset-password", methods=["POST"])
@limiter.limit("10 per hour")
def reset_password():
    data = request.get_json(silent=True) or {}
    token = str(data.get("token", ""))[:200]
    password = str(data.get("password", ""))

    row = fetch_one(
        "SELECT r.id, r.user_id, u.email, u.name FROM password_resets r JOIN users u ON u.id = r.user_id "
        "WHERE r.token_hash = %s AND r.used_at IS NULL AND r.expires_at > NOW()",
        (hash_token(token),),
    )
    if not row:
        return error("This reset link is invalid or has expired. Please request a new one.")
    problem = password_problem(password, row["email"], row["name"])
    if problem:
        return error(problem)

    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute("UPDATE users SET password_hash = %s WHERE id = %s", (generate_password_hash(password), row["user_id"]))
        cur.execute("UPDATE password_resets SET used_at = NOW() WHERE id = %s", (row["id"],))
        cur.execute("DELETE FROM auth_sessions WHERE user_id = %s", (row["user_id"],))   # sign out everywhere
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return with_csrf({"ok": True})

# 9. ORDERS API

@app.route("/api/orders", methods=["POST"])
@login_required
def place_order():
    data = request.get_json(silent=True) or {}
    raw_items = data.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return error("Your cart is empty.")

    quantities = {}   # product id -> quantity (merges repeated ids)
    for item in raw_items:
        try:
            product_id, qty = int(item["id"]), int(item["qty"])
        except (KeyError, TypeError, ValueError):
            return error("Invalid cart data.")
        if qty < 1 or qty > 20:
            return error("Quantity must be between 1 and 20.")
        quantities[product_id] = quantities.get(product_id, 0) + qty

    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        ids = list(quantities)
        marks = ",".join(["%s"] * len(ids))
        cur.execute(f"SELECT id, price FROM products WHERE id IN ({marks})", ids)
        prices = {row["id"]: row["price"] for row in cur.fetchall()}
        if len(prices) != len(ids):
            return error("Some products no longer exist.")

        total = sum(prices[pid] * qty for pid, qty in quantities.items())
        cur.execute("INSERT INTO orders (user_id, total) VALUES (%s, %s)",
                    (current_user()["id"], total))
        order_id = cur.lastrowid
        cur.executemany(
            "INSERT INTO order_items (order_id, product_id, quantity, unit_price) "
            "VALUES (%s, %s, %s, %s)",
            [(order_id, pid, qty, prices[pid]) for pid, qty in quantities.items()],
        )
        conn.commit()          # both tables saved together, or not at all
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    return jsonify({"orderId": order_id, "total": total}), 201

@app.route("/api/orders")
@login_required
def my_orders():
    orders = fetch_all(
        "SELECT id, total, status, created_at FROM orders "
        "WHERE user_id = %s ORDER BY id DESC",
        (current_user()["id"],),
    )
    for order in orders:
        order["items"] = fetch_all(
            "SELECT p.title, oi.quantity, oi.unit_price "
            "FROM order_items oi JOIN products p ON p.id = oi.product_id "
            "WHERE oi.order_id = %s",
            (order["id"],),
        )
        order["created_at"] = order["created_at"].strftime("%d %b %Y, %I:%M %p")
    return jsonify(orders)

# 9b. RETURN ORDER API    POST /api/orders/<id>/return

@app.route("/api/orders/<int:order_id>/return", methods=["POST"])
@login_required
def return_order(order_id):
    # Step 1: Ensure the order exists and belongs to the currently logged-in user
    order = fetch_one(
        "SELECT id, status FROM orders WHERE id = %s AND user_id = %s",
        (order_id, current_user()["id"]),
    )
    if not order:
        return error("Order not found.", 404)

    # Step 2: Prevent multiple return requests if already requested
    if "Return" in order["status"]:
        return error("A return has already been requested for this order.")

    # Step 3: Update order status to 'Return Requested' in the MySQL database
    execute("UPDATE orders SET status = %s WHERE id = %s", ("Return Requested", order_id))
    return jsonify({"ok": True, "status": "Return Requested"})

# 10. SELL FORM      POST /api/sell

@app.route("/api/sell", methods=["POST"])
def sell():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    business = str(data.get("business", "")).strip()
    message = str(data.get("message", "")).strip()[:1000]

    if len(name) < 2 or len(business) < 2:
        return error("Please enter your name and business name.")
    if not valid_email(email):
        return error("Please enter a valid email address.")

    execute(
        "INSERT INTO seller_requests (name, email, business, message) VALUES (%s, %s, %s, %s)",
        (name, email, business, message),
    )
    return jsonify({"ok": True}), 201

if __name__ == "__main__":
    app.run(debug=False)