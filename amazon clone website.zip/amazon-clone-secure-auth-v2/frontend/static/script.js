// ===== 1. HELPERS =====
// Every picture in the project is one of your own photos in frontend/static/images/
const img = name => `/static/images/${name}.jpg`;
const rupee = n => "₹" + Number(n).toLocaleString("en-IN");
const stars = n => "★".repeat(n) + "☆".repeat(5 - n);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// Grey box shown if an image fails to load
const FALLBACK = "data:image/svg+xml;utf8," + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="100%" height="100%" fill="#eaeded"/></svg>');
const pic = (src, alt) => `<img src="${src}" alt="${esc(alt)}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK}'">`;

// Talk to the Flask backend. Throws an Error with the server's message.
async function api(url, options = {}) {
  const method = (options.method || "GET").toUpperCase();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  // Send CSRF token with every state-changing request.
  if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
    const token = document.querySelector('meta[name="csrf-token"]')?.content;
    if (token) headers["X-CSRFToken"] = token;
  }
  let res;
  try {
    res = await fetch(url, {
      credentials: "same-origin",
      ...options,
      method,
      headers
    });
  } catch (networkError) {   // the browser could not reach the server at all ("Failed to fetch")
    throw new Error("Cannot reach the server. Make sure the Flask server is running, then try again.");
  }
  const data = await res.json().catch(() => ({}));
  if (data.csrf) {   // signing in or out starts a new session, so the server sends a fresh CSRF token
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) meta.content = data.csrf;
  }
  if (!res.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

// ===== 2. DATA =====
const heroSlides = [
  { title: "Great Indian Sale", text: "Up to 70% off on electronics", btn: "Shop now", cat: "Electronics",
    img: "hero3", bg: "linear-gradient(135deg, #0f2027, #2c5364)" },
  { title: "Home makeover", text: "Furniture, decor and lighting deals", btn: "Explore home", cat: "Home",
    img: "hero1", bg: "linear-gradient(135deg, #3b2a1e, #8a5a2b)" },
  { title: "Kitchen essentials", text: "Appliances and cookware offers", btn: "See deals", cat: "Home",
    img: "hero2", bg: "linear-gradient(135deg, #1f2937, #475569)" }
];

const categoryCards = [
  { title: "Appliances for your home", link: "See more", cat: "Home", items: [["Air conditioners", "airconditioner", "air conditioner"], ["Refrigerators", "refrigerator", "refrigerator"], ["Microwaves", "microwave", "microwave"], ["Washing machines", "washingmachine", "washing machine"]] },
  { title: "Revamp your home in style", link: "Explore all", cat: "Home", items: [["Cushion covers", "cushion", "cushion cover"], ["Figurines", "figurine", "figurine"], ["Storage", "shelf", "storage"], ["Lighting", "lamp", "lamp"]] },
  { title: "Up to 60% off | Fashion", link: "See all offers", cat: "Fashion", items: [["T-shirts", "tshirt", "t-shirt"], ["Footwear", "sneakers", "shoes|sneakers"], ["Handbags", "handbag", "handbag"], ["Watches", "wristwatch", "watch"]] }
];

let products = [];   // loaded from Flask  (GET /api/products)
let cart = [];       // saved in the browser so a refresh keeps it
let user = null;     // set when signed in

// ===== 3. HERO SLIDER =====
const hero = document.getElementById("hero");
hero.insertAdjacentHTML("afterbegin", heroSlides.map((s, i) => `
  <div class="slide ${i === 0 ? "active" : ""}" style="background:${s.bg}">
    <div class="slide-text"><h2>${s.title}</h2><p>${s.text}</p><button class="btn-yellow" data-nav="cat:${s.cat}">${s.btn}</button></div>
    <div class="slide-bg" style="background-image:url('${img(s.img)}')"></div>
  </div>`).join(""));

const slides = hero.querySelectorAll(".slide");
let current = 0, paused = false, touchX = 0;
function showSlide(i) {
  slides[current].classList.remove("active");
  current = (i + slides.length) % slides.length;
  slides[current].classList.add("active");
}
document.getElementById("nextSlide").onclick = () => showSlide(current + 1);
document.getElementById("prevSlide").onclick = () => showSlide(current - 1);
setInterval(() => { if (!paused) showSlide(current + 1); }, 5000);
hero.addEventListener("mouseenter", () => paused = true);
hero.addEventListener("mouseleave", () => paused = false);
hero.addEventListener("touchstart", e => touchX = e.touches[0].clientX, { passive: true });
hero.addEventListener("touchend", e => {
  const dx = e.changedTouches[0].clientX - touchX;
  if (Math.abs(dx) > 50) showSlide(current + (dx < 0 ? 1 : -1));
});

// ===== 4. CATEGORY CARDS =====
document.getElementById("cardGrid").innerHTML = categoryCards.map(c => `
  <div class="card">
    <h3>${c.title}</h3>
    <div class="tiles">${c.items.map(([name, kw, q]) => `
      <div class="tile" data-nav="item" data-q="${q}" data-label="${name}"><div class="tile-img">${pic(img(kw), name)}</div><p>${name}</p></div>`).join("")}</div>
    <a href="#" class="link" data-nav="cat:${c.cat}">${c.link}</a>
  </div>`).join("") + `
  <div class="card signin-card">
    <h3>Sign in for the best experience</h3>
    <button class="btn-yellow" id="cardSignIn">Sign in securely</button>
    <div class="tile-img">${pic(img("shopping"), "Shopping")}</div>
    <p class="new-customer">New customer? <a href="#" class="link" id="cardRegister">Start here.</a></p>
  </div>`;

// ===== 5. SHOW PRODUCTS =====
const grid = document.getElementById("productGrid");
const productsTitle = document.getElementById("productsTitle");

function showDeals() {
  const deals = [...products].sort((a, b) => b.discount - a.discount).slice(0, 8);
  document.getElementById("dealRow").innerHTML = deals.map(p => `
    <div class="deal" data-nav="item" data-q="${esc(p.title)}" data-label="${esc(p.title)}">
      <div class="deal-img">${pic(p.image, p.title)}</div>
      <span class="badge">${p.discount}% off</span><span class="badge-text">Limited time deal</span>
      <div class="price-line"><span class="price"><small>₹</small>${p.price.toLocaleString("en-IN")}</span>
        <span class="mrp">M.R.P: <s>${rupee(p.oldPrice)}</s></span></div>
    </div>`).join("");
}

function showProducts(list) {
  if (list.length === 0) {
    grid.innerHTML = '<p class="no-results">No results found. Try a different search.</p>';
    return;
  }
  grid.innerHTML = list.map(p => `
    <div class="product">
      <div class="product-img">${pic(p.image, p.title)}</div>
      ${p.reviews > 10000 ? '<span class="best">Best Seller</span>' : ""}
      <a href="#" class="product-title">${esc(p.title)}</a>
      <div class="rating">${stars(p.rating)}<span>${p.reviews.toLocaleString("en-IN")}</span></div>
      <div class="price-line">
        <span class="price"><small>₹</small>${p.price.toLocaleString("en-IN")}</span>
        ${p.discount > 0 ? `<span class="off">(${p.discount}% off)</span>` : ""}
      </div>
      ${p.discount > 0 ? `<div class="mrp">M.R.P: <s>${rupee(p.oldPrice)}</s></div>` : ""}
      <div class="delivery">${p.prime ? '<span class="prime">✔prime</span> ' : ""}${p.category === "Gift Cards" ? "<b>Instant</b> email delivery" : `<b>FREE Delivery</b> ${p.prime ? "by tomorrow" : "on orders above ₹499"}`}</div>
      <button class="btn-yellow" onclick="addToCart(${p.id})">Add to Cart</button>
    </div>`).join("");
}

const decorate = p => ({ ...p, image: img(p.kw), discount: Math.round((1 - p.price / p.oldPrice) * 100) });

// ===== 6. SEARCH (the filtering happens in MySQL via Flask) =====
const searchInput = document.getElementById("searchInput");
const categorySelect = document.getElementById("category");

async function searchProducts() {
  setActiveNav(null);
  const text = searchInput.value.trim();
  const cat = categorySelect.value;
  const params = new URLSearchParams();
  if (text) params.set("q", text);
  if (cat !== "all") params.set("category", cat);
  try {
    const list = await api("/api/products?" + params);
    productsTitle.textContent = text ? `Results for "${text}"` : cat !== "all" ? (catNames[cat] || cat) : "Recommended for you";
    showProducts(list.map(decorate));
  } catch (err) {
    showToast(err.message);
  }
}
document.getElementById("searchBtn").onclick = searchProducts;
searchInput.addEventListener("keyup", e => { if (e.key === "Enter") { hideSuggest(); searchProducts(); } });
categorySelect.onchange = searchProducts;


// ===== 7. CART =====
const cartPanel = document.getElementById("cartPanel");
const overlay = document.getElementById("overlay");
const toast = document.getElementById("toast");
let toastTimer;

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
function openCart() { cartPanel.classList.add("open"); overlay.classList.add("show"); }
function closeCart() { cartPanel.classList.remove("open"); if (!sideMenu.classList.contains("open")) overlay.classList.remove("show"); }

function saveCart() { try { localStorage.setItem("cart", JSON.stringify(cart)); } catch (e) { /* private mode */ } }
function loadCart() {
  try { cart = JSON.parse(localStorage.getItem("cart")) || []; } catch (e) { cart = []; }
}

function addToCart(id) {
  const p = products.find(x => x.id === id);
  const item = cart.find(x => x.id === id);
  if (item) item.qty = Math.min(item.qty + 1, 20);
  else cart.push({ id: p.id, title: p.title, price: p.price, image: p.image, qty: 1 });
  showCart();
  showToast("Added to Cart");
}
function changeQty(id, change) {
  const item = cart.find(x => x.id === id);
  item.qty = Math.min(item.qty + change, 20);
  if (item.qty <= 0) cart = cart.filter(x => x.id !== id);
  showCart();
}
function removeFromCart(id) { cart = cart.filter(x => x.id !== id); showCart(); }

function showCart() {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("cartTotal").textContent = rupee(total);
  document.getElementById("cartItems").innerHTML = cart.length === 0
    ? '<p class="empty-cart">Your Amazon Cart is empty</p>'
    : cart.map(i => `
      <div class="cart-row">
        <div class="thumb">${pic(i.image, i.title)}</div>
        <div class="info">
          ${esc(i.title.length > 45 ? i.title.slice(0, 45) + "…" : i.title)}
          <strong>${rupee(i.price)}</strong>
          <div class="qty"><button onclick="changeQty(${i.id}, -1)">−</button><span>${i.qty}</span><button onclick="changeQty(${i.id}, 1)">+</button></div>
          <button class="remove" onclick="removeFromCart(${i.id})">Delete</button>
        </div>
      </div>`).join("");
  saveCart();
}

document.getElementById("cartBtn").onclick = openCart;
document.getElementById("closeCart").onclick = closeCart;

// Checkout -> POST /api/orders (the server calculates the real total)
document.getElementById("checkoutBtn").onclick = async () => {
  if (cart.length === 0) { showToast("Your cart is empty"); return; }
  if (!user) { closeCart(); showToast("Please sign in to place your order"); openAuth("login"); return; }
  try {
    const order = await api("/api/orders", { method: "POST", body: JSON.stringify({ items: cart.map(i => ({ id: i.id, qty: i.qty })) }) });
    cart = [];
    showCart();
    closeCart();
    showToast(`Order #${order.orderId} placed – ${rupee(order.total)}`);
  } catch (err) {
    showToast(err.message);
  }
};

// ===== 8. SIDE MENU + SEARCH SUGGESTIONS =====
const sideMenu = document.getElementById("sideMenu");
function openMenu() { sideMenu.classList.add("open"); overlay.classList.add("show"); }
function closeMenu() { sideMenu.classList.remove("open"); if (!cartPanel.classList.contains("open")) overlay.classList.remove("show"); }
function closeAll() { closeCart(); closeMenu(); }
function scrollToProducts() { grid.scrollIntoView({ behavior: "smooth", block: "start" }); }

overlay.onclick = closeAll;
document.getElementById("menuBtn").onclick = openMenu;
document.getElementById("allLink").onclick = e => { e.preventDefault(); openMenu(); };

sideMenu.querySelectorAll("[data-act]").forEach(a => a.onclick = e => {
  e.preventDefault();
  const act = a.dataset.act;
  closeAll();
  if (act === "orders" || act === "service" || act === "signin") { go(act); return; }
  if (act === "prime") { document.getElementById("primeLink").click(); return; }
  if (act === "best") {
    productsTitle.textContent = "Best Sellers";
    showProducts(products.filter(p => p.reviews > 10000));
  } else {
    categorySelect.value = act.split(":")[1];
    searchInput.value = "";
    searchProducts();
  }
  scrollToProducts();
});

const suggest = document.getElementById("suggest");
function hideSuggest() { suggest.classList.remove("show"); }
searchInput.addEventListener("input", () => {
  const text = searchInput.value.toLowerCase().trim();
  const matches = text.length < 2 ? [] : products.filter(p => p.title.toLowerCase().includes(text)).slice(0, 6);
  suggest.innerHTML = matches.map(p => `<button type="button">${esc(p.title)}</button>`).join("");
  suggest.classList.toggle("show", matches.length > 0);
  suggest.querySelectorAll("button").forEach(b => b.onmousedown = () => {
    searchInput.value = b.textContent;
    hideSuggest();
    searchProducts();
  });
});
searchInput.addEventListener("blur", () => setTimeout(hideSuggest, 150));

const dealRow = document.getElementById("dealRow");
document.getElementById("dealPrev").onclick = () => dealRow.scrollBy({ left: -600, behavior: "smooth" });
document.getElementById("dealNext").onclick = () => dealRow.scrollBy({ left: 600, behavior: "smooth" });
document.querySelector(".back-top").onclick = e => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); };

// ===== 9. SIGN IN / REGISTER / ORDERS =====
const authModal = document.getElementById("authModal");
const ordersModal = document.getElementById("ordersModal");
let authMode = "login";

function openModal(m) { m.classList.add("show"); }
function closeModals() { document.querySelectorAll(".modal").forEach(m => m.classList.remove("show")); }
document.querySelectorAll("[data-close]").forEach(b => b.onclick = closeModals);
document.querySelectorAll(".modal").forEach(m => m.addEventListener("click", e => { if (e.target === m) closeModals(); }));
document.addEventListener("keydown", e => { if (e.key === "Escape") { closeAll(); closeModals(); hideSuggest(); } });

let resetToken = "";   // filled when the visitor opens the link from the "reset password" email

function setAuthMode(mode) {
  authMode = mode;
  const $ = id => document.getElementById(id);
  const login = mode === "login", reg = mode === "register", forgot = mode === "forgot", reset = mode === "reset";
  $("authTitle").textContent = { login: "Sign in", register: "Create account", forgot: "Reset your password", reset: "Set a new password" }[mode];
  $("authSubmit").textContent = { login: "Sign in", register: "Create your account", forgot: "Send reset link", reset: "Save new password" }[mode];
  $("nameRow").hidden = !reg;
  $("emailRow").hidden = reset;  $("authEmail").required = !reset;        // hidden fields must not block the form
  $("pwRow").hidden = forgot;    $("authPassword").required = !forgot;
  $("pwLabel").textContent = reset ? "New password" : "Password";
  $("authPassword").autocomplete = (reg || reset) ? "new-password" : "current-password";
  if (reg || reset) $("authPassword").setAttribute("minlength", "8"); else $("authPassword").removeAttribute("minlength");
  $("pwHint").hidden = !(reg || reset);
  $("forgotRow").hidden = !login;
  const sw = $("authSwitchText");
  sw.hidden = reset;
  sw.innerHTML = login ? 'New to Amazon? <a href="#" id="authSwitch" class="link">Create your account</a>'
    : reg ? 'Already a customer? <a href="#" id="authSwitch" class="link">Sign in</a>'
    : '<a href="#" id="authSwitch" class="link">Back to sign in</a>';
  const link = $("authSwitch");
  if (link) link.onclick = e => { e.preventDefault(); setAuthMode(login ? "register" : "login"); };
  $("authError").textContent = "";
  $("authInfo").textContent = "";
}
function openAuth(mode) {
  closeAll();
  hidePasswords();
  setAuthMode(mode);
  openModal(authModal);
  document.getElementById({ register: "authName", reset: "authPassword" }[mode] || "authEmail").focus();
}
document.getElementById("forgotLink").onclick = e => { e.preventDefault(); setAuthMode("forgot"); };

document.getElementById("authForm").onsubmit = async e => {
  e.preventDefault();
  const email = document.getElementById("authEmail").value;
  const password = document.getElementById("authPassword").value;
  const errorBox = document.getElementById("authError"), infoBox = document.getElementById("authInfo");
  errorBox.textContent = ""; infoBox.textContent = "";
  try {
    if (authMode === "forgot") {
      await api("/api/forgot-password", { method: "POST", body: JSON.stringify({ email }) });
      infoBox.textContent = "If that email is registered, we have sent a reset link. Check your inbox and spam folder.";
      return;
    }
    if (authMode === "reset") {
      await api("/api/reset-password", { method: "POST", body: JSON.stringify({ token: resetToken, password }) });
      resetToken = ""; user = null; updateAuthUI(); e.target.reset(); setAuthMode("login");
      document.getElementById("authInfo").textContent = "Password changed. Please sign in with your new password.";
      return;
    }
    const body = { email, password };
    if (authMode === "register") body.name = document.getElementById("authName").value;
    const data = await api(authMode === "register" ? "/api/register" : "/api/login", { method: "POST", body: JSON.stringify(body) });
    user = data.user;
    updateAuthUI();
    closeModals();
    e.target.reset();
    showToast(`Welcome, ${user.name.split(" ")[0]}!`);
  } catch (err) {
    errorBox.textContent = err.message;
  }
};

function updateAuthUI() {
  const first = user ? user.name.split(" ")[0] : "";
  document.getElementById("accountHello").textContent = user ? `Hello, ${first}` : "Hello, sign in";
  document.getElementById("accountLabel").textContent = user ? "Your Account ▾" : "Account & Lists ▾";
  document.getElementById("sideHello").textContent = user ? `👤 Hello, ${first}` : "👤 Hello, sign in";
}

const accountModal = document.getElementById("accountModal");
function openAccount() {
  document.getElementById("acctName").textContent = user.name;
  document.getElementById("acctEmail").textContent = user.email || "";
  document.getElementById("changePwForm").hidden = true;
  document.getElementById("changePwError").textContent = "";
  closeAll();
  hidePasswords();
  openModal(accountModal);
}
async function signOut(everywhere) {
  try { await api(everywhere ? "/api/logout-all" : "/api/logout", { method: "POST" }); } catch (e) { /* ignore */ }
  user = null;
  updateAuthUI();
  closeModals();
  showToast(everywhere ? "You have been signed out of all devices" : "You have been signed out");
}
document.getElementById("accountBtn").onclick = () => { if (user) openAccount(); else openAuth("login"); };
document.getElementById("signOutBtn").onclick = () => signOut(false);
document.getElementById("signOutAllBtn").onclick = () => signOut(true);
document.getElementById("changePwBtn").onclick = () => {
  const form = document.getElementById("changePwForm");
  form.hidden = !form.hidden;
  if (!form.hidden) document.getElementById("curPassword").focus();
};
document.getElementById("changePwForm").onsubmit = async e => {
  e.preventDefault();
  const errorBox = document.getElementById("changePwError");
  errorBox.textContent = "";
  try {
    await api("/api/change-password", { method: "POST", body: JSON.stringify({
      current_password: document.getElementById("curPassword").value,
      new_password: document.getElementById("newPassword").value
    }) });
    e.target.reset(); e.target.hidden = true; closeModals();
    showToast("Your password was changed. Other devices were signed out.");
  } catch (err) {
    errorBox.textContent = err.message;
  }
};
document.getElementById("cardSignIn").onclick = () => openAuth("login");
document.getElementById("cardRegister").onclick = e => { e.preventDefault(); openAuth("register"); };

// Helper: asks confirmation and sends return request to the server
async function requestReturn(orderId) {
  const confirmed = confirm("Are you sure you want to request a return for Order #" + orderId + "?");
  if (!confirmed) return;
  try {
    // Send POST request to backend API
    await api("/api/orders/" + orderId + "/return", { method: "POST" });
    showToast("Return request submitted for Order #" + orderId);
    // Refresh the orders list so the updated status is displayed immediately
    document.getElementById("ordersBtn").click();
  } catch (err) {
    showToast(err.message);
  }
}

document.getElementById("ordersBtn").onclick = async () => {
  if (!user) { showToast("Please sign in to see your orders"); openAuth("login"); return; }
  const list = document.getElementById("ordersList");
  list.innerHTML = "<p>Loading…</p>";
  openModal(ordersModal);
  try {
    const orders = await api("/api/orders");
    list.innerHTML = orders.length === 0 ? "<p>You have not placed any orders yet.</p>" : orders.map(o => {
      const isReturned = String(o.status).toLowerCase().includes("return");
      return `
      <div class="order">
        <div class="order-head"><span>Order #${o.id} · ${esc(o.created_at)}</span><span>Total <b>${rupee(o.total)}</b></span><span class="status ${isReturned ? 'return-status' : ''}">${esc(o.status)}</span></div>
        ${o.items.map(i => `<div class="order-item"><span>${esc(i.title)} × ${i.quantity}</span><span>${rupee(i.unit_price * i.quantity)}</span></div>`).join("")}
        <div class="order-actions">
          ${isReturned
            ? '<span class="return-note">Return request submitted</span>'
            : `<button class="btn-yellow btn-return" onclick="requestReturn(${o.id})">Return Request</button>`
          }
        </div>
      </div>`;
    }).join("");
  } catch (err) {
    list.innerHTML = `<p class="form-error">${esc(err.message)}</p>`;
  }
};


// ===== 9b. NAVIGATION: makes every [data-nav] button work =====
const catNames = { Home: "Home & Kitchen" };

function setActiveNav(action) {
  document.querySelectorAll(".subnav a").forEach(a => a.classList.toggle("active", !!action && a.dataset.nav === action));
}

function go(action, data = {}) {
  closeAll();
  closeModals();
  if (action === "home") {
    categorySelect.value = "all";
    searchInput.value = "";
    productsTitle.textContent = "Recommended for you";
    showProducts(products);
    setActiveNav(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else if (action === "deals") {
    productsTitle.textContent = "Today's Deals";
    showProducts([...products].filter(p => p.discount >= 40).sort((a, b) => b.discount - a.discount));
    setActiveNav("deals");
    scrollToProducts();
  } else if (action === "prime") {
    productsTitle.textContent = "Prime eligible products";
    showProducts(products.filter(p => p.prime));
    setActiveNav("prime");
    scrollToProducts();
  } else if (action === "item") {
    categorySelect.value = "all";
    searchInput.value = "";
    setActiveNav(null);
    api("/api/products?" + new URLSearchParams({ q: data.q })).then(list => {
      productsTitle.textContent = data.label;
      showProducts(list.map(decorate));
      scrollToProducts();
    }).catch(err => showToast(err.message));
  } else if (action.startsWith("cat:")) {
    categorySelect.value = action.slice(4);
    searchInput.value = "";
    searchProducts().then(() => { setActiveNav(action); scrollToProducts(); });
  } else if (action === "service") {
    openModal(document.getElementById("serviceModal"));
  } else if (action === "sell") {
    if (user) document.getElementById("sellName").value = user.name;
    openModal(document.getElementById("sellModal"));
    document.getElementById("sellError").textContent = "";
  } else if (action === "orders") {
    document.getElementById("ordersBtn").click();
  } else if (action === "signin") {
    user ? showToast(`You are signed in as ${user.name}`) : openAuth("login");
  }
}

// one listener for every element that has data-nav (nav bar, hero, footer, links)
document.addEventListener("click", e => {
  const el = e.target.closest("[data-nav]");
  if (!el) return;
  e.preventDefault();
  go(el.dataset.nav, el.dataset);
});

// "Sell" form -> POST /api/sell (saved in MySQL table seller_requests)
document.getElementById("sellForm").onsubmit = async e => {
  e.preventDefault();
  try {
    await api("/api/sell", { method: "POST", body: JSON.stringify({
      name: document.getElementById("sellName").value,
      email: document.getElementById("sellEmail").value,
      business: document.getElementById("sellBusiness").value,
      message: document.getElementById("sellMessage").value
    }) });
    e.target.reset();
    closeModals();
    showToast("Thanks! We received your seller request.");
  } catch (err) {
    document.getElementById("sellError").textContent = err.message;
  }
};

// ===== 9c. LANGUAGE SWITCHER (English / हिन्दी / தமிழ்) =====
// How it works: the page is written in English. When you pick another language we look up every
// visible English text in DICT ("English text": [hindi, tamil]) and swap it. New content that appears
// later (cart, toasts, orders...) is translated automatically. Product names come from the database
// and stay in English. To add a sentence, add one line to DICT.
const LANGS = { en: "EN", hi: "HI", ta: "TA" };
const DICT = {
  // Product titles (Tamil translations)
  'Wireless Bluetooth Headphones with Noise Cancellation': ['शोर कम करने वाले वायरलेस ब्लूटूथ हेडफ़ोन', 'இரைச்சல் நீக்கத்துடன் கூடிய வயர்லெஸ் ப்ளூடூத் ஹெட்ஃபோன்கள்'],
  'Smartphone 128GB, 6.5 inch Display, 5G': ['128GB स्मार्टफोन, 6.5 इंच डिस्प्ले, 5G', '128GB ஸ்மார்ட்போன், 6.5 அங்குல திரை, 5G'],
  "Men's Cotton Round Neck T-Shirt (Pack of 2)": ['पुरुषों की कॉटन राउंड नेक टी-शर्ट (2 का पैक)', 'ஆண்களுக்கான பருத்தி வட்ட கழுத்து டி-ஷர்ட் (2 கொண்ட தொகுப்பு)'],
  'Running Shoes for Men, Lightweight and Comfortable': ['पुरुषों के लिए हल्के और आरामदायक रनिंग जूते', 'ஆண்களுக்கான இலகுவான, வசதியான ஓட்டப் பயிற்சி காலணிகள்'],
  'Non-stick Cookware Set, 5 Pieces': ['नॉन-स्टिक कुकवेयर सेट, 5 पीस', 'ஒட்டாத சமையல் பாத்திரத் தொகுப்பு, 5 துண்டுகள்'],
  'LED Table Lamp with Touch Dimmer': ['टच डिमर वाला LED टेबल लैंप', 'தொட்டு ஒளியை மாற்றக்கூடிய LED மேசை விளக்கு'],
  'Atomic Habits by James Clear (Paperback)': ['जेम्स क्लियर की एटॉमिक हैबिट्स पुस्तक (पेपरबैक)', 'ஜேம்ஸ் கிளியரின் Atomic Habits புத்தகம் (பேப்பர்பேக்)'],
  'Laptop 15.6 inch, 8GB RAM, 512GB SSD': ['15.6 इंच लैपटॉप, 8GB RAM, 512GB SSD', '15.6 அங்குல லேப்டாப், 8GB RAM, 512GB SSD'],
  'Smart Watch with Heart Rate and Sleep Tracking': ['हार्ट रेट और स्लीप ट्रैकिंग वाली स्मार्टवॉच', 'இதயத் துடிப்பு மற்றும் தூக்கத்தைக் கண்காணிக்கும் ஸ்மார்ட் வாட்ச்'],
  'Backpack for Laptop, Water Resistant, 30L': ['लैपटॉप के लिए वाटर-रेसिस्टेंट बैकपैक, 30 लीटर', 'லேப்டாப்புக்கான நீர் எதிர்ப்பு பேக், 30 லிட்டர்'],
  'Ceramic Coffee Mug Set of 6': ['6 सिरेमिक कॉफी मग का सेट', '6 செராமிக் காபி குவளைகள் கொண்ட தொகுப்பு'],
  'Bestselling Novel Collection, Set of 3 Books': ['बेस्टसेलिंग उपन्यास संग्रह, 3 पुस्तकों का सेट', 'அதிகம் விற்பனையான நாவல்கள், 3 புத்தகத் தொகுப்பு'],
  'Smartphone 256GB, 6.7 inch AMOLED, 5G, 50MP Camera': ['256GB स्मार्टफोन, 6.7 इंच AMOLED, 5G, 50MP कैमरा', '256GB ஸ்மார்ட்போன், 6.7 அங்குல AMOLED, 5G, 50MP கேமரா'],
  'Budget Smartphone 64GB, 6.5 inch Display, 5000mAh Battery': ['बजट स्मार्टफोन 64GB, 6.5 इंच डिस्प्ले, 5000mAh बैटरी', '64GB மலிவு விலை ஸ்மார்ட்போன், 6.5 அங்குல திரை, 5000mAh பேட்டரி'],
  'Flagship Smartphone 512GB, Triple Camera, Fast Charging': ['512GB फ्लैगशिप स्मार्टफोन, ट्रिपल कैमरा, फास्ट चार्जिंग', '512GB உயர்தர ஸ்மார்ட்போன், மூன்று கேமராக்கள், வேகமான சார்ஜிங்'],
  'Amazon Gift Card - Rs 500 (Email Delivery)': ['Amazon गिफ्ट कार्ड - ₹500 (ईमेल डिलीवरी)', 'Amazon பரிசு அட்டை - ₹500 (மின்னஞ்சல் மூலம்)'],
  'Amazon Gift Card - Rs 1,000 (Email Delivery)': ['Amazon गिफ्ट कार्ड - ₹1,000 (ईमेल डिलीवरी)', 'Amazon பரிசு அட்டை - ₹1,000 (மின்னஞ்சல் மூலம்)'],
  'Amazon Gift Card - Rs 2,000 (Email Delivery)': ['Amazon गिफ्ट कार्ड - ₹2,000 (ईमेल डिलीवरी)', 'Amazon பரிசு அட்டை - ₹2,000 (மின்னஞ்சல் மூலம்)'],
  'Amazon Gift Card - Rs 5,000 (Email Delivery)': ['Amazon गिफ्ट कार्ड - ₹5,000 (ईमेल डिलीवरी)', 'Amazon பரிசு அட்டை - ₹5,000 (மின்னஞ்சல் மூலம்)'],
  'Split Air Conditioner 1.5 Ton, 5 Star Inverter': ['स्प्लिट एयर कंडीशनर 1.5 टन, 5 स्टार इन्वर्टर', '1.5 டன், 5 நட்சத்திர இன்வெர்ட்டர் ஸ்ப்ளிட் ஏசி'],
  'Double Door Refrigerator 260L, Frost Free': ['डबल डोर रेफ्रिजरेटर 260 लीटर, फ्रॉस्ट फ्री', '260 லிட்டர், ஃப்ராஸ்ட் ஃப்ரீ இரட்டை கதவு குளிர்சாதனப் பெட்டி'],
  'Convection Microwave Oven 28L with Auto Cook Menus': ['ऑटो कुक मेनू वाला 28 लीटर कन्वेक्शन माइक्रोवेव ओवन', 'ஆட்டோ குக் வசதியுடன் 28 லிட்டர் கன்வெக்ஷன் மைக்ரோவேவ்'],
  'Front Load Washing Machine 7 kg, Fully Automatic': ['फ्रंट लोड वॉशिंग मशीन 7 किलो, पूरी तरह स्वचालित', '7 கிலோ முழு தானியங்கி முன்புற ஏற்றும் வாஷிங் மெஷின்'],
  'Textured Cushion Cover Set of 5 (16 x 16 inch)': ['टेक्सचर्ड कुशन कवर का सेट, 5 पीस (16 x 16 इंच)', 'அழகிய வடிவமைப்புள்ள குஷன் உறைகள், 5 தொகுப்பு (16 x 16 அங்குலம்)'],
  'Brass Finish Ganesha Figurine Showpiece for Home Decor': ['घर की सजावट के लिए पीतल रंग की गणेश प्रतिमा', 'வீட்டு அலங்காரத்திற்கான பித்தளை நிற விநாயகர் சிலை'],
  'Wooden Bookshelf, 5-Tier Storage Rack for Home': ['घर के लिए 5-स्तरीय लकड़ी की बुकशेल्फ़', 'வீட்டிற்கான 5 அடுக்கு மர புத்தக அலமாரி'],
  'Ceramic Table Lamp with Fabric Shade for Bedroom': ['बेडरूम के लिए कपड़े की शेड वाला सिरेमिक टेबल लैंप', 'படுக்கையறைக்கான துணி மூடியுடன் கூடிய செராமிக் மேசை விளக்கு'],
  "Show password": ["पासवर्ड दिखाएँ", "கடவுச்சொல்லைக் காட்டு"],
  "Hide password": ["पासवर्ड छिपाएँ", "கடவுச்சொல்லை மறை"],
  "Cannot reach the server. Make sure the Flask server is running, then try again.": ["सर्वर से संपर्क नहीं हो पा रहा। जाँचें कि Flask सर्वर चल रहा है, फिर कोशिश करें।", "சர்வரை அணுக முடியவில்லை. Flask சர்வர் இயங்குகிறதா என்று பார்த்து மீண்டும் முயற்சிக்கவும்."],
  // --- sign-in, password reset and account messages ---
  "Forgot your password?": ["पासवर्ड भूल गए?", "கடவுச்சொல்லை மறந்துவிட்டீர்களா?"],
  "Reset your password": ["अपना पासवर्ड रीसेट करें", "உங்கள் கடவுச்சொல்லை மீட்டமைக்கவும்"],
  "Set a new password": ["नया पासवर्ड सेट करें", "புதிய கடவுச்சொல்லை அமைக்கவும்"],
  "Send reset link": ["रीसेट लिंक भेजें", "மீட்டமைப்பு இணைப்பை அனுப்பு"],
  "Back to sign in": ["साइन इन पर वापस जाएँ", "உள்நுழைவுக்குத் திரும்பு"],
  "New password": ["नया पासवर्ड", "புதிய கடவுச்சொல்"],
  "Save new password": ["नया पासवर्ड सहेजें", "புதிய கடவுச்சொல்லைச் சேமி"],
  "Current password": ["वर्तमान पासवर्ड", "தற்போதைய கடவுச்சொல்"],
  "Change password": ["पासवर्ड बदलें", "கடவுச்சொல்லை மாற்று"],
  "Sign out": ["साइन आउट", "வெளியேறு"],
  "Sign out of all devices": ["सभी डिवाइस से साइन आउट करें", "எல்லா சாதனங்களிலிருந்தும் வெளியேறு"],
  "Your Account ▾": ["आपका खाता ▾", "உங்கள் கணக்கு ▾"],
  "Use 8 or more characters. Avoid easy passwords such as \"password123\".": ["8 या अधिक अक्षर इस्तेमाल करें। \"password123\" जैसे आसान पासवर्ड से बचें।", "8 அல்லது அதற்கு மேற்பட்ட எழுத்துகளைப் பயன்படுத்துங்கள். \"password123\" போன்ற எளிய கடவுச்சொற்களைத் தவிர்க்கவும்."],
  "If that email is registered, we have sent a reset link. Check your inbox and spam folder.": ["अगर यह ईमेल पंजीकृत है, तो हमने रीसेट लिंक भेज दिया है। अपना इनबॉक्स और स्पैम फ़ोल्डर देखें।", "அந்த மின்னஞ்சல் பதிவு செய்யப்பட்டிருந்தால், மீட்டமைப்பு இணைப்பை அனுப்பியுள்ளோம். உங்கள் இன்பாக்ஸ் மற்றும் ஸ்பேம் கோப்புறையைப் பாருங்கள்."],
  "Password changed. Please sign in with your new password.": ["पासवर्ड बदल गया। कृपया अपने नए पासवर्ड से साइन इन करें।", "கடவுச்சொல் மாற்றப்பட்டது. புதிய கடவுச்சொல்லுடன் உள்நுழையவும்."],
  "Your password was changed. Other devices were signed out.": ["आपका पासवर्ड बदल गया। अन्य डिवाइस साइन आउट कर दिए गए।", "உங்கள் கடவுச்சொல் மாற்றப்பட்டது. மற்ற சாதனங்கள் வெளியேற்றப்பட்டன."],
  "You have been signed out of all devices": ["आप सभी डिवाइस से साइन आउट हो गए हैं", "நீங்கள் எல்லா சாதனங்களிலிருந்தும் வெளியேறிவிட்டீர்கள்"],
  "Too many attempts. Please wait a few minutes and try again.": ["बहुत अधिक प्रयास। कृपया कुछ मिनट बाद फिर कोशिश करें।", "அதிக முயற்சிகள். சில நிமிடங்களுக்குப் பிறகு மீண்டும் முயற்சிக்கவும்."],
  "Security check failed. Refresh the page and try again.": ["सुरक्षा जाँच विफल रही। पेज रीफ़्रेश करें और फिर कोशिश करें।", "பாதுகாப்பு சோதனை தோல்வியடைந்தது. பக்கத்தை புதுப்பித்து மீண்டும் முயற்சிக்கவும்."],
  "Password must be 8 to 128 characters.": ["पासवर्ड 8 से 128 अक्षरों का होना चाहिए।", "கடவுச்சொல் 8 முதல் 128 எழுத்துகள் இருக்க வேண்டும்."],
  "That password is too easy to guess. Please choose a stronger one.": ["यह पासवर्ड अनुमान लगाने में बहुत आसान है। कृपया मज़बूत पासवर्ड चुनें।", "இந்த கடவுச்சொல்லை எளிதில் ஊகிக்கலாம். வலுவான ஒன்றைத் தேர்ந்தெடுக்கவும்."],
  "This reset link is invalid or has expired. Please request a new one.": ["यह रीसेट लिंक अमान्य है या समाप्त हो चुका है। कृपया नया लिंक मँगवाएँ।", "இந்த மீட்டமைப்பு இணைப்பு செல்லாதது அல்லது காலாவதியாகிவிட்டது. புதிய ஒன்றைக் கோருங்கள்."],
  "Your current password is incorrect.": ["आपका वर्तमान पासवर्ड गलत है।", "உங்கள் தற்போதைய கடவுச்சொல் தவறானது."],
  "Choose a password different from your current one.": ["अपने वर्तमान पासवर्ड से अलग पासवर्ड चुनें।", "தற்போதைய கடவுச்சொல்லிலிருந்து வேறுபட்ட ஒன்றைத் தேர்ந்தெடுக்கவும்."],
  "Incorrect email or password.": ["ईमेल या पासवर्ड गलत है।", "மின்னஞ்சல் அல்லது கடவுச்சொல் தவறானது."],
  "Please enter your name.": ["कृपया अपना नाम दर्ज करें।", "உங்கள் பெயரை உள்ளிடவும்."],
  "Please enter a valid email address.": ["कृपया मान्य ईमेल पता दर्ज करें।", "சரியான மின்னஞ்சல் முகவரியை உள்ளிடவும்."],
  "An account with this email already exists.": ["इस ईमेल से खाता पहले से मौजूद है।", "இந்த மின்னஞ்சலுடன் ஏற்கனவே ஒரு கணக்கு உள்ளது."],
  "Please sign in first.": ["कृपया पहले साइन इन करें।", "முதலில் உள்நுழையவும்."],
  "Skip to products": ["उत्पादों पर जाएँ", "பொருட்களுக்குச் செல்"],
  "Delivering to": ["डिलीवरी स्थान", "டெலிவரி இடம்"],
  "Update location": ["स्थान अपडेट करें", "இடத்தைப் புதுப்பிக்கவும்"],
  "📍 Delivering to –": ["📍 डिलीवरी स्थान –", "📍 டெலிவரி இடம் –"],
  "All": ["सभी", "அனைத்தும்"], "☰ All": ["☰ सभी", "☰ அனைத்தும்"],
  "Mobiles": ["मोबाइल", "மொபைல்கள்"], "Electronics": ["इलेक्ट्रॉनिक्स", "எலக்ட்ரானிக்ஸ்"],
  "Fashion": ["फैशन", "ஃபேஷன்"], "Home": ["घर", "வீடு"], "Books": ["किताबें", "புத்தகங்கள்"],
  "Gift Cards": ["गिफ्ट कार्ड", "பரிசு அட்டைகள்"], "Home & Kitchen": ["घर और किचन", "வீடு & சமையலறை"],
  "Hello, sign in": ["नमस्ते, साइन इन करें", "வணக்கம், உள்நுழைக"], "👤 Hello, sign in": ["👤 नमस्ते, साइन इन करें", "👤 வணக்கம், உள்நுழைக"],
  "Account & Lists ▾": ["खाता और सूचियाँ ▾", "கணக்கு & பட்டியல்கள் ▾"], "Sign out ▾": ["साइन आउट ▾", "வெளியேறு ▾"],
  "Returns": ["रिटर्न", "திருப்பி அனுப்புதல்"], "& Orders": ["और ऑर्डर", "& ஆர்டர்கள்"], "Cart": ["कार्ट", "கார்ட்"],
  "Today's Deals": ["आज के ऑफ़र", "இன்றைய சலுகைகள்"], "Customer Service": ["ग्राहक सेवा", "வாடிக்கையாளர் சேவை"], "Sell": ["बेचें", "விற்கவும்"],
  "Change language": ["भाषा बदलें", "மொழியை மாற்று"], "Language": ["भाषा", "மொழி"],
  "Search Amazon.in": ["Amazon.in पर खोजें", "Amazon.in-இல் தேடுங்கள்"],
  // banners and cards
  "Great Indian Sale": ["ग्रेट इंडियन सेल", "கிரேட் இந்தியன் சேல்"],
  "Up to 70% off on electronics": ["इलेक्ट्रॉनिक्स पर 70% तक की छूट", "எலக்ட்ரானிக்ஸ் மீது 70% வரை தள்ளுபடி"],
  "Shop now": ["अभी खरीदें", "இப்போதே வாங்கு"], "Home makeover": ["होम मेकओवर", "வீட்டு அலங்காரம்"],
  "Furniture, decor and lighting deals": ["फर्नीचर, सजावट और लाइटिंग ऑफ़र", "தளபாடங்கள், அலங்காரம் & விளக்கு சலுகைகள்"],
  "Explore home": ["घर देखें", "வீட்டுப் பொருட்களைப் பார்க்க"], "Kitchen essentials": ["किचन की ज़रूरी चीज़ें", "சமையலறை அத்தியாவசியங்கள்"],
  "Appliances and cookware offers": ["उपकरण और कुकवेयर ऑफ़र", "உபகரணங்கள் & சமையல் பாத்திர சலுகைகள்"],
  "See deals": ["ऑफ़र देखें", "சலுகைகளைப் பார்"],
  "Appliances for your home": ["आपके घर के उपकरण", "உங்கள் வீட்டுக்கான உபகரணங்கள்"],
  "Air conditioners": ["एयर कंडीशनर", "ஏர் கண்டிஷனர்கள்"], "Refrigerators": ["रेफ्रिजरेटर", "குளிர்சாதனப் பெட்டிகள்"],
  "Microwaves": ["माइक्रोवेव", "மைக்ரோவேவ்கள்"], "Washing machines": ["वॉशिंग मशीन", "சலவை இயந்திரங்கள்"],
  "See more": ["और देखें", "மேலும் பார்க்க"], "Revamp your home in style": ["अपने घर को नया स्टाइल दें", "உங்கள் வீட்டை புதுப்பொலிவாக்குங்கள்"],
  "Cushion covers": ["कुशन कवर", "குஷன் கவர்கள்"], "Figurines": ["मूर्तियाँ", "சிலைகள்"], "Storage": ["स्टोरेज", "சேமிப்பு"],
  "Lighting": ["लाइटिंग", "விளக்குகள்"], "Explore all": ["सभी देखें", "அனைத்தையும் ஆராய்க"],
  "Up to 60% off | Fashion": ["60% तक की छूट | फैशन", "60% வரை தள்ளுபடி | ஃபேஷன்"],
  "T-shirts": ["टी-शर्ट", "டி-ஷர்ட்கள்"], "Footwear": ["जूते-चप्पल", "காலணிகள்"], "Handbags": ["हैंडबैग", "கைப்பைகள்"],
  "Watches": ["घड़ियाँ", "கடிகாரங்கள்"], "See all offers": ["सभी ऑफ़र देखें", "அனைத்து சலுகைகளையும் பார்"],
  "Sign in for the best experience": ["बेहतरीन अनुभव के लिए साइन इन करें", "சிறந்த அனுபவத்திற்கு உள்நுழையவும்"],
  "Sign in securely": ["सुरक्षित रूप से साइन इन करें", "பாதுகாப்பாக உள்நுழையவும்"],
  "New customer?": ["नए ग्राहक?", "புதிய வாடிக்கையாளரா?"], "Start here.": ["यहाँ से शुरू करें।", "இங்கே தொடங்குங்கள்."],
  // products
  "See all deals": ["सभी ऑफ़र देखें", "அனைத்து சலுகைகளையும் பார்"], "Limited time deal": ["सीमित समय का ऑफ़र", "குறைந்த கால சலுகை"],
  "M.R.P:": ["अधिकतम मूल्य:", "அதிகபட்ச விலை:"], "Recommended for you": ["आपके लिए सुझाव", "உங்களுக்காக பரிந்துரைகள்"],
  "Best Seller": ["बेस्ट सेलर", "அதிகம் விற்பனையானது"], "FREE Delivery": ["मुफ़्त डिलीवरी", "இலவச டெலிவரி"],
  "by tomorrow": ["कल तक", "நாளைக்குள்"], "on orders above ₹499": ["₹499 से ऊपर के ऑर्डर पर", "₹499-க்கு மேல் ஆர்டர்களுக்கு"],
  "Instant": ["तुरंत", "உடனடி"], "email delivery": ["ईमेल डिलीवरी", "மின்னஞ்சல் டெலிவரி"],
  "Add to Cart": ["कार्ट में जोड़ें", "கார்ட்டில் சேர்"], "Prime eligible products": ["प्राइम योग्य उत्पाद", "பிரைம் தகுதியுள்ள பொருட்கள்"],
  "No results found. Try a different search.": ["कोई परिणाम नहीं मिला। कृपया दूसरी खोज आज़माएँ।", "முடிவுகள் இல்லை. வேறு தேடலை முயற்சிக்கவும்."],
  // side menu
  "Trending": ["ट्रेंडिंग", "பிரபலமானவை"], "Best Sellers": ["बेस्ट सेलर", "அதிகம் விற்பனையானவை"],
  "Prime Products": ["प्राइम उत्पाद", "பிரைம் பொருட்கள்"], "Shop by category": ["श्रेणी के अनुसार खरीदें", "வகை வாரியாக வாங்குக"],
  "Help & Settings": ["सहायता और सेटिंग", "உதவி & அமைப்புகள்"], "Your Orders": ["आपके ऑर्डर", "உங்கள் ஆர்டர்கள்"],
  "Sign in": ["साइन इन", "உள்நுழை"],
  // cart + account
  "Shopping Cart": ["शॉपिंग कार्ट", "ஷாப்பிங் கார்ட்"], "Your Amazon Cart is empty": ["आपका Amazon कार्ट खाली है", "உங்கள் Amazon கார்ட் காலியாக உள்ளது"],
  "Subtotal:": ["कुल राशि:", "மொத்தம்:"], "Proceed to Buy": ["खरीदने के लिए आगे बढ़ें", "வாங்க தொடரவும்"], "Delete": ["हटाएँ", "நீக்கு"],
  "Create account": ["खाता बनाएँ", "கணக்கை உருவாக்கு"], "Your name": ["आपका नाम", "உங்கள் பெயர்"], "Email": ["ईमेल", "மின்னஞ்சல்"],
  "Password": ["पासवर्ड", "கடவுச்சொல்"], "New to Amazon?": ["Amazon पर नए हैं?", "Amazon-க்கு புதியவரா?"],
  "Create your account": ["अपना खाता बनाएँ", "உங்கள் கணக்கை உருவாக்குங்கள்"], "Already a customer?": ["पहले से ग्राहक हैं?", "ஏற்கனவே வாடிக்கையாளரா?"],
  "Loading…": ["लोड हो रहा है…", "ஏற்றுகிறது…"], "Total": ["कुल", "மொத்தம்"], "Placed": ["दिया गया", "செய்யப்பட்டது"], "Delivered": ["डिलीवर हो गया", "டெலிவரி செய்யப்பட்டது"],
  "You have not placed any orders yet.": ["आपने अभी तक कोई ऑर्डर नहीं किया है।", "நீங்கள் இன்னும் எந்த ஆர்டரும் செய்யவில்லை."],
  // customer service + sell
  "📦 Your Orders": ["📦 आपके ऑर्डर", "📦 உங்கள் ஆர்டர்கள்"], "👤 Sign in / Account": ["👤 साइन इन / खाता", "👤 உள்நுழை / கணக்கு"],
  "🏷️ Today's Deals": ["🏷️ आज के ऑफ़र", "🏷️ இன்றைய சலுகைகள்"],
  "Frequently asked questions": ["अक्सर पूछे जाने वाले प्रश्न", "அடிக்கடி கேட்கப்படும் கேள்விகள்"],
  "How do I track my order?": ["मैं अपना ऑर्डर कैसे ट्रैक करूँ?", "என் ஆர்டரை எப்படி கண்காணிப்பது?"],
  "Sign in and open": ["साइन इन करें और खोलें", "உள்நுழைந்து திறக்கவும்"], "Returns & Orders": ["रिटर्न और ऑर्डर", "திருப்பி அனுப்புதல் & ஆர்டர்கள்"],
  ". Every order you placed is listed with its status.": [". आपके सभी ऑर्डर उनकी स्थिति के साथ यहाँ दिखते हैं।", ". நீங்கள் செய்த ஒவ்வொரு ஆர்டரும் அதன் நிலையுடன் பட்டியலிடப்படும்."],
  "How do I return an item?": ["मैं कोई सामान कैसे लौटाऊँ?", "ஒரு பொருளை எப்படி திருப்பி அனுப்புவது?"],
  "Open your order, choose the item and select a return reason. Refunds go back to the original payment method in 5–7 days.": ["अपना ऑर्डर खोलें, सामान चुनें और रिटर्न का कारण चुनें। रिफ़ंड 5–7 दिनों में मूल भुगतान माध्यम में वापस आ जाता है।", "உங்கள் ஆர்டரைத் திறந்து, பொருளைத் தேர்ந்தெடுத்து, திருப்பி அனுப்பும் காரணத்தைத் தேர்வு செய்யுங்கள். பணம் 5–7 நாட்களில் அசல் கட்டண முறைக்குத் திரும்பும்."],
  "How long does delivery take?": ["डिलीवरी में कितना समय लगता है?", "டெலிவரிக்கு எவ்வளவு நேரம் ஆகும்?"],
  "Prime items arrive the next day. Other items usually arrive in 3–5 days. Gift cards arrive instantly by email.": ["प्राइम सामान अगले दिन पहुँचता है। अन्य सामान आमतौर पर 3–5 दिनों में आता है। गिफ्ट कार्ड ईमेल से तुरंत मिलते हैं।", "பிரைம் பொருட்கள் மறுநாள் வந்துவிடும். மற்றவை பொதுவாக 3–5 நாட்களில் வரும். பரிசு அட்டைகள் மின்னஞ்சலில் உடனே கிடைக்கும்."],
  "I forgot my password": ["मैं अपना पासवर्ड भूल गया", "கடவுச்சொல்லை மறந்துவிட்டேன்"],
  "Password reset is not part of this demo yet. Create a new account with a different email to continue.": ["पासवर्ड रीसेट अभी इस डेमो में नहीं है। जारी रखने के लिए दूसरे ईमेल से नया खाता बनाएँ।", "கடவுச்சொல் மீட்டமைப்பு இந்த டெமோவில் இன்னும் இல்லை. தொடர வேறு மின்னஞ்சலுடன் புதிய கணக்கை உருவாக்குங்கள்."],
  "Need more help? Email": ["और मदद चाहिए? ईमेल करें", "மேலும் உதவி வேண்டுமா? மின்னஞ்சல் செய்யுங்கள்"], "(demo address).": ["(डेमो पता)।", "(டெமோ முகவரி)."],
  "Sell on Amazon": ["Amazon पर बेचें", "Amazon-இல் விற்கவும்"],
  "Reach millions of customers. Tell us about your business and we will contact you.": ["लाखों ग्राहकों तक पहुँचें। अपने व्यवसाय के बारे में बताएँ, हम आपसे संपर्क करेंगे।", "மில்லியன் கணக்கான வாடிக்கையாளர்களைச் சென்றடையுங்கள். உங்கள் வணிகம் பற்றி சொல்லுங்கள், நாங்கள் தொடர்பு கொள்வோம்."],
  "Business name": ["व्यवसाय का नाम", "வணிகப் பெயர்"], "What do you want to sell?": ["आप क्या बेचना चाहते हैं?", "நீங்கள் என்ன விற்க விரும்புகிறீர்கள்?"],
  "Register as a seller": ["विक्रेता के रूप में पंजीकरण करें", "விற்பனையாளராக பதிவு செய்யுங்கள்"],
  // footer
  "Back to top": ["ऊपर जाएँ", "மேலே செல்ல"], "Get to Know Us": ["हमारे बारे में जानें", "எங்களைப் பற்றி அறிக"],
  "About Us": ["हमारे बारे में", "எங்களைப் பற்றி"], "Careers": ["करियर", "வேலைவாய்ப்புகள்"], "Press Releases": ["प्रेस विज्ञप्तियाँ", "செய்தி வெளியீடுகள்"],
  "Connect with Us": ["हमसे जुड़ें", "எங்களுடன் இணையுங்கள்"], "Make Money with Us": ["हमारे साथ कमाएँ", "எங்களுடன் சம்பாதியுங்கள்"],
  "Become an Affiliate": ["एफ़िलिएट बनें", "இணைப்பு உறுப்பினராகுங்கள்"], "Advertise Your Products": ["अपने उत्पादों का विज्ञापन करें", "உங்கள் பொருட்களை விளம்பரப்படுத்துங்கள்"],
  "Let Us Help You": ["हम आपकी मदद करें", "நாங்கள் உதவுகிறோம்"], "Your Account": ["आपका खाता", "உங்கள் கணக்கு"],
  "Returns Centre": ["रिटर्न केंद्र", "திருப்பி அனுப்பும் மையம்"], "Help": ["सहायता", "உதவி"],
  "Practice project for learning – not the real Amazon.": ["सीखने के लिए प्रैक्टिस प्रोजेक्ट – असली Amazon नहीं।", "கற்றலுக்கான பயிற்சித் திட்டம் – உண்மையான Amazon அல்ல."],
  // messages
  "Added to Cart": ["कार्ट में जोड़ा गया", "கார்ட்டில் சேர்க்கப்பட்டது"],
  "Please sign in to place your order": ["ऑर्डर देने के लिए कृपया साइन इन करें", "ஆர்டர் செய்ய உள்நுழையவும்"],
  "Please sign in to see your orders": ["अपने ऑर्डर देखने के लिए कृपया साइन इन करें", "உங்கள் ஆர்டர்களைப் பார்க்க உள்நுழையவும்"],
  "Thanks! We received your seller request.": ["धन्यवाद! हमें आपका विक्रेता अनुरोध मिल गया।", "நன்றி! உங்கள் விற்பனையாளர் கோரிக்கை கிடைத்தது."],
  "You have been signed out": ["आप साइन आउट हो गए हैं", "நீங்கள் வெளியேறிவிட்டீர்கள்"],
  "Your cart is empty": ["आपका कार्ट खाली है", "உங்கள் கார்ட் காலியாக உள்ளது"]
};
// sentences with a changing part: [pattern, [hindi, tamil]]
const PATTERNS = [
  [/^\((\d+)% off\)$/, ["($1% की छूट)", "($1% தள்ளுபடி)"]],
  [/^(\d+)% off$/, ["$1% की छूट", "$1% தள்ளுபடி"]],
  [/^Results for "(.+)"$/, ["\"$1\" के लिए परिणाम", "\"$1\" க்கான முடிவுகள்"]],
  [/^Order #(\d+) placed – (.+)$/, ["ऑर्डर #$1 दिया गया – $2", "ஆர்டர் #$1 செய்யப்பட்டது – $2"]],
  [/^Order #(\d+) · (.+)$/, ["ऑर्डर #$1 · $2", "ஆர்டர் #$1 · $2"]],
  [/^Welcome, (.+)!$/, ["स्वागत है, $1!", "வரவேற்கிறோம், $1!"]],
  [/^👤 Hello, (.+)$/, ["👤 नमस्ते, $1", "👤 வணக்கம், $1"]],
  [/^Hello, (.+)$/, ["नमस्ते, $1", "வணக்கம், $1"]],
  [/^You are signed in as (.+)$/, ["आप $1 के रूप में साइन इन हैं", "நீங்கள் $1 ஆக உள்நுழைந்துள்ளீர்கள்"]]
];

let lang = "en";
try { const saved = localStorage.getItem("lang"); if (LANGS[saved]) lang = saved; } catch (e) { /* private mode */ }
const origText = new WeakMap();   // text node -> its English text
const shownText = new WeakMap();  // text node -> the text we last displayed

function tr(text) {               // English -> current language (returns the text unchanged if unknown)
  if (lang === "en") return text;
  const i = lang === "hi" ? 0 : 1;
  const m = text.match(/^(\s*)([\s\S]*?)(\s*)$/);
  const core = m[2].replace(/\s+/g, " ");
  if (Object.prototype.hasOwnProperty.call(DICT, core)) return m[1] + DICT[core][i] + m[3];
  for (const [re, outs] of PATTERNS) if (re.test(core)) return m[1] + core.replace(re, outs[i]) + m[3];
  return text;
}

function translateText(node) {
  const p = node.parentNode;
  if (!p || /^(SCRIPT|STYLE|TEXTAREA)$/.test(p.nodeName)) return;
  // if the app wrote new text into this node, that text is the new English original
  if (!origText.has(node) || node.nodeValue !== shownText.get(node)) origText.set(node, node.nodeValue);
  const out = tr(origText.get(node));
  if (out !== node.nodeValue) node.nodeValue = out;
  shownText.set(node, node.nodeValue);
}

function translateTree(root) {
  if (root.nodeType === 3) { translateText(root); return; }
  if (root.nodeType !== 1) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = walker.nextNode())) translateText(n);
  for (const attr of ["placeholder", "aria-label", "title"]) {
    root.querySelectorAll(`[${attr}]`).forEach(el => {
      const keep = "data-en-" + attr;                       // remember the English text
      if (!el.hasAttribute(keep)) el.setAttribute(keep, el.getAttribute(attr));
      el.setAttribute(attr, tr(el.getAttribute(keep)));
    });
  }
}

// translate anything the app adds or changes later (cart rows, toasts, orders, product cards...)
new MutationObserver(list => {
  for (const m of list) {
    if (m.type === "characterData") translateText(m.target);
    else m.addedNodes.forEach(translateTree);
  }
}).observe(document.body, { childList: true, subtree: true, characterData: true });

function setLanguage(code) {
  if (!LANGS[code]) return;
  lang = code;
  try { localStorage.setItem("lang", code); } catch (e) { /* ignore */ }
  document.documentElement.lang = code;
  translateTree(document.body);
  document.getElementById("langShort").textContent = LANGS[code];
  document.querySelectorAll("[data-lang]").forEach(el => {
    const on = el.dataset.lang === code;
    el.classList.toggle("is-current", on);
    if (el.getAttribute("role") === "menuitemradio") el.setAttribute("aria-checked", String(on));
  });
}

// the "EN ▾" button in the header
const langBtn = document.getElementById("langBtn");
function closeLangMenu() { langBtn.classList.remove("open"); langBtn.setAttribute("aria-expanded", "false"); }
langBtn.addEventListener("click", e => {
  const option = e.target.closest("[data-lang]");
  if (option) { setLanguage(option.dataset.lang); closeLangMenu(); return; }
  langBtn.setAttribute("aria-expanded", String(langBtn.classList.toggle("open")));
});
langBtn.addEventListener("keydown", e => {
  if (e.target === langBtn && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); langBtn.click(); }
});
document.addEventListener("click", e => { if (!e.target.closest("#langBtn")) closeLangMenu(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeLangMenu(); });
// language links inside the side menu (used on phones and tablets)
sideMenu.querySelectorAll("a[data-lang]").forEach(a => a.onclick = e => { e.preventDefault(); setLanguage(a.dataset.lang); closeAll(); });

setLanguage(lang);   // apply the saved language on page load

// ===== Show / hide password (the eye icon next to each password box) =====
document.addEventListener("click", e => {
  const button = e.target.closest(".pw-toggle");
  if (!button) return;
  const input = button.parentElement.querySelector("input");
  const show = input.type === "password";
  input.type = show ? "text" : "password";
  button.classList.toggle("on", show);
  button.setAttribute("aria-pressed", String(show));
  const label = show ? "Hide password" : "Show password";
  button.setAttribute("data-en-aria-label", label);
  button.setAttribute("aria-label", tr(label));
  input.focus();
});
function hidePasswords() {   // every password box goes back to dots when a window opens
  document.querySelectorAll(".pw-toggle.on").forEach(b => b.click());
}
document.querySelectorAll(".toggle-password").forEach((button) => {
  button.addEventListener("click", () => {
    const input = button.parentElement.querySelector("input");

    if (!input) return;

    input.type = input.type === "password" ? "text" : "password";
  });
});

// ===== DELIVERY LOCATION =====
const LOCATION_STORAGE_KEY = "amazonCloneDeliveryLocation";
const locationModal = document.getElementById("locationModal");
const locationForm = document.getElementById("locationForm");
const locationInput = document.getElementById("locationInput");
const locationError = document.getElementById("locationError");
const deliveryLocationText = document.getElementById("deliveryLocationText");
const deliveryLocationStripText = document.getElementById("deliveryLocationStripText");

function updateDeliveryLocation(value) {
  const label = value || "Update location";
  deliveryLocationText.textContent = label;
  deliveryLocationStripText.textContent = label;
  deliveryLocationText.title = label;
  deliveryLocationStripText.title = label;
}
function openLocationPicker() {
  try { locationInput.value = localStorage.getItem(LOCATION_STORAGE_KEY) || ""; } catch (e) { locationInput.value = ""; }
  locationError.textContent = "";
  openModal(locationModal);
  setTimeout(() => locationInput.focus(), 0);
}
document.getElementById("deliveryLocationBtn").addEventListener("click", openLocationPicker);
document.getElementById("deliveryLocationStrip").addEventListener("click", openLocationPicker);
locationForm.addEventListener("submit", e => {
  e.preventDefault();
  const value = locationInput.value.trim().replace(/\s+/g, " ");
  if (value.length < 3) {
    locationError.textContent = "Enter a valid city, area or 6-digit PIN code.";
    locationInput.focus();
    return;
  }
  if (/^\d+$/.test(value) && !/^\d{6}$/.test(value)) {
    locationError.textContent = "PIN code must contain exactly 6 digits.";
    locationInput.focus();
    return;
  }
  try { localStorage.setItem(LOCATION_STORAGE_KEY, value); } catch (e) { /* keep working for this page session */ }
  updateDeliveryLocation(value);
  closeModals();
  if (typeof showToast === "function") showToast("Delivery location updated");
});
document.getElementById("clearLocationBtn").addEventListener("click", () => {
  try { localStorage.removeItem(LOCATION_STORAGE_KEY); } catch (e) { /* ignore */ }
  locationInput.value = "";
  updateDeliveryLocation("");
  closeModals();
});
try { updateDeliveryLocation(localStorage.getItem(LOCATION_STORAGE_KEY) || ""); } catch (e) { updateDeliveryLocation(""); }

// ===== 10. START =====
async function init() {
  loadCart();
  showCart();
  const [me, list] = await Promise.allSettled([api("/api/me"), api("/api/products")]);
  if (me.status === "fulfilled") { user = me.value.user; updateAuthUI(); }
  const resetLink = location.hash.match(/^#reset=([\w-]+)$/);       // the token stays in the #part: it is never sent to servers
  if (resetLink) {
    resetToken = resetLink[1];
    history.replaceState(null, "", location.pathname + location.search);   // remove it from the address bar
    openAuth("reset");
  }
  if (list.status === "fulfilled") {
    products = list.value.map(decorate);
    showDeals();
    showProducts(products);
  } else {
    grid.innerHTML = '<p class="no-results">Could not load products. Is the Flask server and MySQL running?</p>';
  }
}
init();