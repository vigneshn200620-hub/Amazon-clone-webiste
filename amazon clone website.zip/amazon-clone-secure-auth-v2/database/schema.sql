SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS amazon_clone CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE amazon_clone;

DROP TABLE IF EXISTS password_resets;
DROP TABLE IF EXISTS auth_sessions;
DROP TABLE IF EXISTS seller_requests;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

-- 1. People who sign up (passwords are stored hashed, never as plain text)
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1b. Login sessions. The cookie holds a random id; only its SHA-256 hash is stored here.
--     Deleting a row signs that device out (logout, "sign out of all devices", password change).
CREATE TABLE auth_sessions (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  token_hash CHAR(64) NOT NULL UNIQUE,
  user_id    INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  INDEX idx_sessions_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 1c. "Forgot password" links. One-time, valid for 30 minutes; only the token's hash is stored.
CREATE TABLE password_resets (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  used_at    DATETIME NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 2. Things for sale (prices are whole rupees)
CREATE TABLE products (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  title     VARCHAR(255) NOT NULL,
  category  VARCHAR(50)  NOT NULL,
  price     INT NOT NULL,
  old_price INT NOT NULL,
  rating    TINYINT NOT NULL DEFAULT 4,
  reviews   INT NOT NULL DEFAULT 0,
  image     VARCHAR(60) NOT NULL,       -- file name in static/images (without .jpg)
  is_prime  BOOLEAN NOT NULL DEFAULT TRUE,
  INDEX idx_category (category)
);

-- 3. One row per order
CREATE TABLE orders (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  total      INT NOT NULL,
  status     VARCHAR(20) NOT NULL DEFAULT 'Placed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 4. The products inside each order
CREATE TABLE order_items (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  order_id   INT NOT NULL,
  product_id INT NOT NULL,
  quantity   INT NOT NULL,
  unit_price INT NOT NULL,              -- price at the time of buying
  FOREIGN KEY (order_id)   REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO products (id, title, category, price, old_price, rating, reviews, image, is_prime) VALUES
(1,  'Wireless Bluetooth Headphones with Noise Cancellation', 'Electronics', 1999, 4999, 4, 12450, 'headphones',   TRUE),
(2,  'Smartphone 128GB, 6.5 inch Display, 5G',                'Mobiles',     14999, 19999, 4, 8920, 'smartphone',   TRUE),
(3,  'Men''s Cotton Round Neck T-Shirt (Pack of 2)',          'Fashion',     499, 1299, 4, 3210,   'tshirt',       TRUE),
(4,  'Running Shoes for Men, Lightweight and Comfortable',    'Fashion',     1299, 2999, 4, 5420,  'runningshoes', FALSE),
(5,  'Non-stick Cookware Set, 5 Pieces',                      'Home',        1799, 3499, 5, 2150,  'cookware',     TRUE),
(6,  'LED Table Lamp with Touch Dimmer',                      'Home',        699, 1499, 4, 980,    'desklamp',     TRUE),
(7,  'Atomic Habits by James Clear (Paperback)',              'Books',       399, 699, 5, 45300,   'book',         TRUE),
(8,  'Laptop 15.6 inch, 8GB RAM, 512GB SSD',                  'Electronics', 38990, 52990, 4, 1760,'laptop',       FALSE),
(9,  'Smart Watch with Heart Rate and Sleep Tracking',        'Electronics', 2499, 6999, 4, 7340,  'smartwatch',   TRUE),
(10, 'Backpack for Laptop, Water Resistant, 30L',             'Fashion',     899, 1999, 4, 4120,   'backpack',     TRUE),
(11, 'Ceramic Coffee Mug Set of 6',                           'Home',        549, 999, 4, 1270,    'coffeemug',    TRUE),
(12, 'Bestselling Novel Collection, Set of 3 Books',          'Books',       799, 1497, 5, 2890,   'bookset',      FALSE),
(13, 'Smartphone 256GB, 6.7 inch AMOLED, 5G, 50MP Camera',       'Mobiles',     24999, 29999, 4, 5230,  'mobile2',      TRUE),
(14, 'Budget Smartphone 64GB, 6.5 inch Display, 5000mAh Battery', 'Mobiles',   8999, 11999, 4, 15800, 'mobile3',      TRUE),
(15, 'Flagship Smartphone 512GB, Triple Camera, Fast Charging',   'Mobiles',     59999, 74999, 5, 2410,  'mobile4',      FALSE),
(16, 'Amazon Gift Card - Rs 500 (Email Delivery)',                'Gift Cards',  500, 500, 5, 8210,      'giftcard500',  TRUE),
(17, 'Amazon Gift Card - Rs 1,000 (Email Delivery)',              'Gift Cards',  1000, 1000, 5, 6120,    'giftcard1000', TRUE),
(18, 'Amazon Gift Card - Rs 2,000 (Email Delivery)',              'Gift Cards',  2000, 2000, 5, 3340,    'giftcard2000', TRUE),
(19, 'Amazon Gift Card - Rs 5,000 (Email Delivery)',              'Gift Cards',  5000, 5000, 5, 1250,    'giftcard5000', TRUE),
(20, 'Split Air Conditioner 1.5 Ton, 5 Star Inverter',               'Home',    38990, 58990, 4, 4210, 'airconditioner', TRUE),
(21, 'Double Door Refrigerator 260L, Frost Free',                    'Home',    26490, 34990, 4, 3180, 'refrigerator',   TRUE),
(22, 'Convection Microwave Oven 28L with Auto Cook Menus',           'Home',    9990,  14990, 4, 2670, 'microwave',      FALSE),
(23, 'Front Load Washing Machine 7 kg, Fully Automatic',             'Home',    24990, 33990, 4, 1980, 'washingmachine', TRUE),
(24, 'Textured Cushion Cover Set of 5 (16 x 16 inch)',               'Home',    599,   1299,  4, 5120, 'cushion',        TRUE),
(25, 'Brass Finish Ganesha Figurine Showpiece for Home Decor',       'Home',    749,   1499,  5, 3650, 'figurine',       TRUE),
(26, 'Wooden Bookshelf, 5-Tier Storage Rack for Home',               'Home',    5499,  9999,  4, 1430, 'shelf',          FALSE),
(27, 'Ceramic Table Lamp with Fabric Shade for Bedroom',             'Home',    1499,  2999,  4, 2240, 'lamp',           TRUE),
(28, 'Men''s Casual Black Sneakers with Soft Rubber Sole',             'Fashion', 1699,  3499,  4, 6210, 'sneakers',       TRUE),
(29, 'Women''s Leather Tote Handbag with Dual Handles',              'Fashion', 1999,  4999,  4, 4390, 'handbag',        TRUE),
(30, 'Men''s Analog Wrist Watch with Stainless Steel Strap',         'Fashion', 2999,  6999,  4, 2980, 'wristwatch',     FALSE);

-- 5. Requests from the "Sell" form
CREATE TABLE IF NOT EXISTS seller_requests (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL,
  business   VARCHAR(150) NOT NULL,
  message    TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- 6. Demo account (password: Demo@12345 - stored hashed, like every real account)
INSERT INTO users (id, name, email, password_hash, created_at) VALUES
(1, 'Demo User', 'demo@amazon-clone.com', 'scrypt:32768:8:1$S2TjF7elXrJ9L5Bm$d19282d7eabb9d51f1c46fccb97698a0a6c88f6e46c7ad3feb85621ec98f78157e24345e57e5c6f5b4f1c4556f864eeba90b0a46a9c1760597c9654c4b2ce08d', '2026-09-20 10:00:00');

-- 7. One sample order for the demo account (2 products, total Rs 2,797)
INSERT INTO orders (id, user_id, total, status, created_at) VALUES
(1, 1, 2797, 'Delivered', '2026-09-20 11:30:00');

INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1, 1, 1, 1999),
(1, 7, 2, 399);